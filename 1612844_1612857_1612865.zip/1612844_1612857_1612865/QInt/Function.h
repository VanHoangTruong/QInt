#include <string>
using namespace std;

string divDecStringByTwo(string);
string mulDecStringWithTwo(string);
string addTowDecString(string, string);
string mulDecStringWithFive(string, int);
